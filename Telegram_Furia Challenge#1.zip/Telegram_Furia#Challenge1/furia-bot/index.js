const TelegramBot = require('node-telegram-bot-api');

const token = '7598945994:AAF5oRND07FGNgqLR_we8D_1Rv9guktAGmk';

const bot = new TelegramBot(token, { polling: true });

// Controlar quais usuários já foram Logados
let usuariosLogado = new Set();

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  // Verifica se o usuário já foi Logado
  if (!usuariosLogado.has(userId)) {
    // Se não foi Logado, envia a mensagem e marca como Logado
    bot.sendMessage(chatId, `Bem-vindo ao chat da torcida FURIA, ${msg.from.first_name}!\nUse /status para saber como está o jogo! 🐯\nUse /torcida para entrar no clima da galera!\nUse /calendario para ficar por dentro dos próximos jogos!\nUse /melhoresmomentos para ver os melhores highlights da sua vida!!`);
    usuariosLogado.add(userId); // Marca o usuário como Logado
  }
});

bot.onText(/\/status/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, `🔥 Tá rolando jogo agoooooraaaaaaa, galerinhaaa!!`);
  bot.sendMessage(chatId, `🔥 FURIA está ganhando por 2-1 na série contra NAVI! 🐯`);
});

let torcidaAtiva = false;

bot.onText(/\/torcida/, (msg) => {
  const chatId = msg.chat.id;

  if (torcidaAtiva) {
    bot.sendMessage(chatId, "🗣️ A torcida já está rolando!");
    return;
  }

  torcidaAtiva = true;

  const falas = [
    "🔥 VAMOS FURIAAAA!!!",
    "🐯 É hoje que a NAVI vai cair!",
    "💥 Confio no FalleN!",
    "🏆 Esse é o nosso campeonato!",
    "📢 AAAAAA VAI FURIAAAA",
  ];

  let i = 0;

  const intervalo = setInterval(() => {
    if (i >= falas.length) {
      clearInterval(intervalo);
      torcidaAtiva = false;
      return;
    }

    bot.sendMessage(chatId, falas[i]);
    i++;
  }, 2000);
});

// Reações automáticas a mensagens de torcida
bot.on('message', (msg) => {
  const chatId = msg.chat.id;

  if (msg.text.includes('🔥')) {
    bot.sendMessage(chatId, '🔥 A torcida está pegando fogo! Vai FURIA!!');
  } else if (msg.text.toLowerCase().includes('vamos')) {
    bot.sendMessage(chatId, '🐯 VAMOS COM TUDO, FURIAAA!');
  }
});

// Comando /calendario
bot.onText(/\/calendario/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, `📅 Não há partidas de FURIA CS2 (CS:GO) agendadas no momento. 😔`);
});

// Comando /melhoresmomentos
bot.onText(/\/melhoresmomentos/, (msg) => {
  const chatId = msg.chat.id;
  const melhoresMomentosLinks = [
    "[Melhores Momentos - FURIA vs NAVI](https://www.youtube.com/shorts/akNCw41CWsc?feature=share)",
    "[Melhores Momentos - FURIA - CS:GO](https://www.youtube.com/shorts/MYQ7iJ-vIUQ?feature=share)",
    "[Melhores Momentos - FURIA no Major](https://www.youtube.com/shorts/clwEddt5jFM?feature=share)"
  ];

  const message = `🎥 *Melhores Momentos da FURIA!*\n\n${melhoresMomentosLinks.join('\n')}`;

  bot.sendMessage(chatId, message, { parse_mode: "Markdown" }); // adicionei pq não estava dando click
});

// Tratamento de erros de polling
bot.on("polling_error", (error) => {
  console.error("Erro no polling:", error.code, error.response?.body || error.message);
});

